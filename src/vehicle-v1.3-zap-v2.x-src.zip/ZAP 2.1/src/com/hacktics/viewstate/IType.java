package com.hacktics.viewstate;

public interface IType {

    public int getType();
}


