﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ViewStateControls
{
    public partial class Submitted : System.Web.UI.Page
    {
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            if (!IsPostBack)
            {
                Button btnClickMe = new Button();

                form1.Controls.Add(btnClickMe);
                btnClickMe.Text = "Click me";
            }
            else
            {
                Label label = new Label();
                label.ID = "label";
                form1.Controls.Add(label);
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {

            
        }
    }
}