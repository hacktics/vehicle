﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;

using System.ComponentModel;
using System.Collections;
using System.IO;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

namespace ViewStateControls
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {

                if (TextBoxUsername.Text == null || TextBoxPassword.Text == null)
                {
                    Response.Write("<br><b><center>Invalid Username or Password</center></b><br>");
                }

                if (TextBoxUsername.Text.Trim() == "" || TextBoxPassword.Text.Trim() == "")
                {
                    Response.Write("<br><b><center>Invalid Username or Password</center></b><br>");
                }

                if (TextBoxUsername.Text == "user1" && TextBoxPassword.Text == "password")
                {
                    Session["user"] = "user1";
                    CommonValues.activeUsers.Add((String)Session["user"]);
                    Response.Redirect("/WelcomePage.aspx");
                }
                else if (TextBoxUsername.Text == "admin" && TextBoxPassword.Text == "mastermold")
                {
                    Session["user"] = "admin";
                    CommonValues.activeUsers.Add((String)Session["user"]);
                    Response.Redirect("/WelcomePage.aspx");
                }
                else
                {
                    Response.Write("<br><b><center>Invalid Username or Password</center></b><br>");
                }

                /*
                MySqlConnection cnn = new MySqlConnection("Server=localhost;Database=wavsepdb;Uid=testuser;Pwd=ab312jd843;");
                cnn.Open();

                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = cnn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "SELECT username FROM users " +
                                "WHERE username = @uname AND password = @pass";
                cmd.Parameters.AddWithValue("@uname", TextBoxUsername.Text);
                cmd.Parameters.AddWithValue("@pass", TextBoxPassword.Text);

                MySqlDataReader reader = cmd.ExecuteReader();


                if (reader.Read())
                {
                    Session["user"] = reader.GetString(0);

                    CommonValues.activeUsers.Add((String)Session["user"]);

                    Response.Redirect("/WelcomePage.aspx");
                }
                else
                {
                    Response.Write("<br><b><center>Invalid Username or Password</center></b><br>");
                }
                reader.Close();
                cnn.Close();
                
                */
                
            } //end of postback if

        } //end of method

    } //end of class
} //end of namespace