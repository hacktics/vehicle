﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ViewStateControls
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        private String currentStatus = "Up";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] != null)
            {
                Response.Write("<center><font size=5>System Control Monitor</font></center><br>");
                Response.Write("<center>Welcome " + Session["user"] + "</center><br>");
            }
            else
            {
                Response.Redirect("/Logout.aspx");
            }
        }
        
    }
}