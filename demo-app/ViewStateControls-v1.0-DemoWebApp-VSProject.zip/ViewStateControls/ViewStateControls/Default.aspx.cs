﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Text;
using System.Web.Compilation;
using System.Web.Handlers;
using System.Web.Util;
using System.Diagnostics;
using System.Security.Cryptography;
using System.Web.Configuration;

namespace ViewStateControls
{
    public partial class _Default : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }
    }
}
