﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Web;

namespace ViewStateControls
{
    
    public class CommonValues
    {
        public static List<string> activeUsers = new List<string>();

    }
}