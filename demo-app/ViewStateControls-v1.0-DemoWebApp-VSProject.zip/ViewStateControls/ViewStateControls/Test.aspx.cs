﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Text;
using System.Web.Compilation;
using System.Web.Handlers;
using System.Web.Util;
using System.Diagnostics;
using System.Security.Cryptography;
using System.Web.Configuration;

namespace ViewStateControls
{
    public partial class Test : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            ViewState["Text1"] = Textbox1.Text;
            ViewState["Text2"] = TextBox2.Text;

            if (ListBox1.SelectedItem != null)
                Label1.Text = "You selected: " + ListBox1.SelectedItem.Value;
            else
                Label1.Text = "";

            //MachineKeyConfig mconfig = HttpContext.GetAppConfig("system.web/machineKey") as MachineKeyConfig;
            //-algoKey = mconfig.ValidationKey;
            foreach (String a in WebConfigurationManager.AppSettings.AllKeys) {
                Debug.WriteLine(a);
                }
            
                
            //WebConfigurationManager.GetWebApplicationSection(


        }

        protected void CallMe_Click()
        {
            ListBox1.Items.Add(new ListItem("bbbb"));
        }

        protected void DoSubmit(object sender, EventArgs e)
        {
            ListBox1.Items.Add(new ListItem("aaa"));
            //tesing!!
            int pageHashCode = StringComparer.InvariantCultureIgnoreCase.GetHashCode(
                   Page.TemplateSourceDirectory);
            pageHashCode += StringComparer.InvariantCultureIgnoreCase.GetHashCode(Page.GetType().Name);

            string viewStateUserKey = Page.ViewStateUserKey;

            Label1.Text += "$$$" + GetStringHashCode("ctl00$MainContent$Button2");
            Label1.Text += "$$$" + (GetStringHashCode("ctl00$MainContent$Button2") ^ GetStringHashCode("Button"));

            WriteEncoded(-1094037335);    


            
        }

        // This is copied from String.GetHashCode.  We want our own copy, because the result of
        // String.GetHashCode is not guaranteed to be the same from build to build.  But we want a 
        // stable hash, since we persist things to disk (e.g. precomp scenario).  VSWhidbey 399279.
        internal static int GetStringHashCode(string s)
        {
            unsafe
            {
                fixed (char* src = s)
                {
                    int hash1 = (5381 << 16) + 5381;
                    int hash2 = hash1;

                    // 32bit machines.
                    int* pint = (int*)src;
                    int len = s.Length;
                    while (len > 0)
                    {
                        hash1 = ((hash1 << 5) + hash1 + (hash1 >> 27)) ^ pint[0];
                        if (len <= 2)
                        {
                            break;
                        }
                        hash2 = ((hash2 << 5) + hash2 + (hash2 >> 27)) ^ pint[1];
                        pint += 2;
                        
                        len -= 4;
                    }
                    return hash1 + (hash2 * 1566083941);
                }
            }
        }

        private byte[] GetMacKeyModifier()
        {
            byte[] _macKeyBytes = null;
            if (_macKeyBytes == null)
            {
                // Only generate a MacKeyModifier if we have a page
             
                // Note: duplicated in MobilePage.cs, keep in [....] 

                // Use the page's directory and class name as part of the key (ASURT 64044) 
                // We need to make sure that the hash is case insensitive, since the file system 
                // is, and strange view state errors could otherwise happen (ASURT 128657)
                
                int pageHashCode = StringComparer.InvariantCultureIgnoreCase.GetHashCode(
                    this.TemplateSourceDirectory);
                pageHashCode += StringComparer.InvariantCultureIgnoreCase.GetHashCode(this.GetType().Name);

           
                _macKeyBytes = new byte[4];
                 Debug.WriteLine(pageHashCode);
                 Debug.WriteLine(this.TemplateSourceDirectory);
                 Debug.WriteLine(this.GetType().Name);


                _macKeyBytes[0] = (byte)pageHashCode;
                _macKeyBytes[1] = (byte)(pageHashCode >> 8);
                _macKeyBytes[2] = (byte)(pageHashCode >> 16);
                _macKeyBytes[3] = (byte)(pageHashCode >> 24);
            }
            return _macKeyBytes;
        }

        public void WriteEncoded(int value)
        {
            //

            uint v = (uint)value;
            while (v >= 0x80)
            {
                Console.WriteLine((byte)(v | 0x80));
                v >>= 7;
            }
            Console.WriteLine((byte)v);
        } 

        protected void Button1_Click(object sender, EventArgs e)
        {

        }

        protected void ButtonInvisible_Click(object sender, EventArgs e)
        {
            
            ViewState["Text1"] = "Label" + ViewState["Text1"];
            Label1.Text = ViewState["Text1"].ToString();
            LabelForInvisible.Text = "Invisible" + ViewState["Text2"].ToString();
            
        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {
           // LabelForInvisible.Text = ViewState["Text2"].ToString();
        }

        protected void RadioButton3_CheckedChanged(object sender, EventArgs e)
        {
          //  LabelForInvisible.Text = "Radio" + ViewState["Text1"].ToString();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            LabelForInvisible.Text = "Button2 Clicked";
        }

        protected void Button1_Command(object sender, CommandEventArgs e)
        {

        }

        protected void CheckBox145455_CheckedChanged(object sender, EventArgs e)
        {
            Label1.Text = "Checkbox145455 checked changed=" + CheckBox145455.Checked;
        }

        protected void Textbox1_TextChanged(object sender, EventArgs e)
        {
            Label1.Text = "TextBox1 TextChanged Event"+Textbox1.Text;
        }
    }
}
