﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ViewStateControls
{
    public partial class ControlPanelSection1 : System.Web.UI.Page
    {
        private String currentStatus = "Up";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] != null)
            {
                if (!((String)Session["user"]).Equals("admin"))
                {
                    Button2.Visible = false;
                    Button3.Enabled = false;
                    TextBox1.Enabled = false;
                }
                else
                {
                    Button2.Visible = true;
                    Button3.Enabled = true;
                    TextBox1.Enabled = true;
                }

                Response.Write("<center><font size=5>System Control Monitor</font></center><br>");
                Response.Write("<center>Welcome " + Session["user"] + "</center><br>");
            }
            else
            {
                Response.Redirect("/Logout.aspx");
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Label1.Text = "<b>Server Is " + currentStatus + "</b>";
            Label1.ForeColor = System.Drawing.Color.Black;
            Label1.BorderColor = System.Drawing.Color.Brown;
            //Response.Write("<center>Server Is " + currentStatus + "</center>");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Label1.Text = "<b>Shutting Down Server...</b>";
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.BorderColor = System.Drawing.Color.Brown;
            //Response.Write("<center>Shutting Down Server</center>");
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Label1.Text = "<b>Notification Sent to " + TextBox1.Text + "</b>";
            Label1.ForeColor = System.Drawing.Color.Green;
            Label1.BorderColor = System.Drawing.Color.Red;
            //Response.Write("<center>Notification Sent to Admin</center>");
            //Response.Redirect("/WelcomePage222.aspx");
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            /*
            Response.Write("<center><b>Active Users</b></center>");
            Response.Write("<center><table bgcolor='#1AC6FF'><tr><td>");
            foreach (String item in CommonValues.activeUsers)
            {
                
                Response.Write("<center>" + item + "</center><br>");
                
            }
            Response.Write("</td></tr></table></center><br><br>");
            */

            String msg = "";
            msg = msg + "<b>Active Users</b><br>";
            
            foreach (String item in CommonValues.activeUsers)
            {

                msg = msg + item + "<br>";

            }

            Label1.Text = msg;
            Label1.ForeColor = System.Drawing.Color.Black;
            Label1.BorderColor = System.Drawing.Color.Brown;
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Logout.aspx");
        }
    }
}